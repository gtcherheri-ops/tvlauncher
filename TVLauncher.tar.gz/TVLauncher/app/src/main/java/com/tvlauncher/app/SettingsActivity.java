package com.tvlauncher.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;

/** Halaman pengaturan kecil untuk launcher. */
public class SettingsActivity extends Activity {
    private static final int REQUEST_PICK_WALLPAPER_FOLDER = 101;

    private LauncherPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        preferences = new LauncherPreferences(this);

        findViewById(R.id.action_set_home).setOnClickListener(v -> openHomeSettings());
        findViewById(R.id.action_wallpaper).setOnClickListener(v -> openWallpaperPicker());
        findViewById(R.id.action_wallpaper_folder).setOnClickListener(v -> pickWallpaperFolder());
        findViewById(R.id.action_wallpaper_interval).setOnClickListener(v -> chooseInterval());
        findViewById(R.id.action_wallpaper_fade).setOnClickListener(v -> chooseFade());
        findViewById(R.id.action_wallpaper_next).setOnClickListener(v -> requestNextWallpaper());
        findViewById(R.id.action_wallpaper_toggle).setOnClickListener(v -> toggleWallpaper());
        findViewById(R.id.action_manage_apps).setOnClickListener(v -> openManageApps());
        findViewById(R.id.action_about).setOnClickListener(v -> showAbout());
        findViewById(R.id.action_back).setOnClickListener(v -> finish());

        updateWallpaperLabels();

        View firstItem = findViewById(R.id.action_set_home);
        firstItem.post(firstItem::requestFocus);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK_WALLPAPER_FOLDER
                || resultCode != RESULT_OK
                || data == null
                || data.getData() == null) {
            return;
        }

        Uri treeUri = data.getData();
        try {
            int flags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if (flags != 0) {
                getContentResolver().takePersistableUriPermission(treeUri, flags);
            }
        } catch (SecurityException ignored) {
            // Izin tidak dapat dipertahankan; gambar mungkin tetap terbaca untuk sesi ini.
        }
        preferences.setTreeUri(treeUri.toString());
        preferences.setEnabled(true);
        Toast.makeText(this, R.string.wallpaper_saved, Toast.LENGTH_SHORT).show();
    }

    private void updateWallpaperLabels() {
        int minutes = preferences.getIntervalMinutes();
        ((android.widget.TextView) findViewById(R.id.action_wallpaper_interval))
                .setText(getString(R.string.wallpaper_interval, minutes));

        int fade = preferences.getFadeMs();
        String fadeLabel = fade <= 0
                ? getString(R.string.wallpaper_fade_off)
                : getString(R.string.wallpaper_fade, fade);
        ((android.widget.TextView) findViewById(R.id.action_wallpaper_fade)).setText(fadeLabel);

        int label = preferences.isEnabled()
                ? R.string.wallpaper_disable
                : R.string.wallpaper_enable;
        ((android.widget.TextView) findViewById(R.id.action_wallpaper_toggle)).setText(label);
    }

    private void pickWallpaperFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        if (intent.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, R.string.wallpaper_no_picker, Toast.LENGTH_LONG).show();
            return;
        }
        startActivityForResult(intent, REQUEST_PICK_WALLPAPER_FOLDER);
    }

    private void chooseInterval() {
        String[] labels = getResources().getStringArray(R.array.wallpaper_intervals);
        int current = 1;
        for (int i = 0; i < LauncherPreferences.INTERVAL_VALUES.length; i++) {
            if (LauncherPreferences.INTERVAL_VALUES[i] == preferences.getIntervalMinutes()) {
                current = i;
                break;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.wallpaper_interval_title)
                .setSingleChoiceItems(labels, current, (dialog, which) -> {
                    preferences.setIntervalMinutes(LauncherPreferences.INTERVAL_VALUES[which]);
                    preferences.setEnabled(true);
                    updateWallpaperLabels();
                    dialog.dismiss();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void chooseFade() {
        String[] labels = getResources().getStringArray(R.array.wallpaper_fades);
        int current = 2;
        for (int i = 0; i < LauncherPreferences.FADE_VALUES.length; i++) {
            if (LauncherPreferences.FADE_VALUES[i] == preferences.getFadeMs()) {
                current = i;
                break;
            }
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.wallpaper_fade_title)
                .setSingleChoiceItems(labels, current, (dialog, which) -> {
                    preferences.setFadeMs(LauncherPreferences.FADE_VALUES[which]);
                    updateWallpaperLabels();
                    dialog.dismiss();
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void requestNextWallpaper() {
        preferences.setEnabled(true);
        preferences.requestNext();
        finish();
    }

    private void toggleWallpaper() {
        preferences.setEnabled(!preferences.isEnabled());
        updateWallpaperLabels();
    }

    private void openHomeSettings() {
        Intent intent = new Intent(Settings.ACTION_HOME_SETTINGS);
        if (intent.resolveActivity(getPackageManager()) == null) {
            intent = new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS);
        }
        if (intent.resolveActivity(getPackageManager()) == null) {
            Toast.makeText(this, R.string.home_settings_unavailable, Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.home_settings_unavailable, Toast.LENGTH_LONG).show();
        }
    }

    private void openWallpaperPicker() {
        Intent intent = Intent.createChooser(
                new Intent(Intent.ACTION_SET_WALLPAPER), getString(R.string.setting_wallpaper));
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.home_settings_unavailable, Toast.LENGTH_LONG).show();
        }
    }

    private void openManageApps() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.home_settings_unavailable, Toast.LENGTH_LONG).show();
        }
    }

    private void showAbout() {
        String version = "1.0";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        new AlertDialog.Builder(this)
                .setTitle(R.string.about_title)
                .setMessage(getString(R.string.about_message, version))
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}
