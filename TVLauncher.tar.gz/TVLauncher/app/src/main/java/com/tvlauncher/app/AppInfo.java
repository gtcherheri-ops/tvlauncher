package com.tvlauncher.app;

import android.content.Intent;
import android.graphics.drawable.Drawable;

/** Data sederhana untuk satu aplikasi yang bisa diluncurkan. */
public class AppInfo {
    private final String label;
    private final String packageName;
    private final Intent launchIntent;
    private final Drawable icon;

    public AppInfo(String label, String packageName, Intent launchIntent, Drawable icon) {
        this.label = label;
        this.packageName = packageName;
        this.launchIntent = launchIntent;
        this.icon = icon;
    }

    public String getLabel() {
        return label;
    }

    public String getPackageName() {
        return packageName;
    }

    public Intent getLaunchIntent() {
        return launchIntent;
    }

    /** Ikon dibuat ulang agar bisa dipakai oleh banyak ImageView sekaligus. */
    public Drawable newIcon() {
        if (icon == null) {
            return null;
        }
        Drawable.ConstantState state = icon.getConstantState();
        return state != null ? state.newDrawable() : icon;
    }
}
