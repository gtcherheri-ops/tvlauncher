package com.tvlauncher.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Menyimpan daftar aplikasi favorit secara lokal. */
public class FavoritesManager {
    private static final String PREF_NAME = "tv_launcher_prefs";
    private static final String KEY_FAVORITES = "favorites";

    private final SharedPreferences preferences;

    public FavoritesManager(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public Set<String> getFavoritePackages() {
        Set<String> stored = preferences.getStringSet(KEY_FAVORITES, Collections.<String>emptySet());
        return new HashSet<>(stored);
    }

    public boolean isFavorite(AppInfo app) {
        return getFavoritePackages().contains(app.getPackageName());
    }

    public void toggle(AppInfo app) {
        Set<String> favorites = getFavoritePackages();
        String packageName = app.getPackageName();
        if (!favorites.add(packageName)) {
            favorites.remove(packageName);
        }
        preferences.edit().putStringSet(KEY_FAVORITES, favorites).apply();
    }

    public List<AppInfo> getFavorites(List<AppInfo> allApps) {
        Set<String> packages = getFavoritePackages();
        List<AppInfo> result = new ArrayList<>();
        for (AppInfo app : allApps) {
            if (packages.contains(app.getPackageName())) {
                result.add(app);
            }
        }
        return result;
    }
}
