package com.tvlauncher.app;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Kartu aplikasi dengan efek fokus saat dinavigasi memakai remote D-pad. */
public class AppCardView extends LinearLayout {
    private final ImageView iconView;
    private final TextView labelView;

    public AppCardView(Context context) {
        super(context);
        init(context);
    }

    private void init(Context context) {
        setOrientation(VERTICAL);
        setGravity(Gravity.CENTER);
        setBackgroundResource(R.drawable.bg_app_card_selector);
        setFocusable(true);
        setClickable(true);
        setLayoutParams(new LayoutParams(dp(context, 150), dp(context, 150)));

        iconView = new ImageView(context);
        iconView.setLayoutParams(new LayoutParams(dp(context, 64), dp(context, 64)));
        iconView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        addView(iconView);

        labelView = new TextView(context);
        LayoutParams labelParams = new LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        labelParams.topMargin = dp(context, 10);
        labelView.setLayoutParams(labelParams);
        labelView.setGravity(Gravity.CENTER);
        labelView.setMaxLines(2);
        labelView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        labelView.setTextColor(getResources().getColor(R.color.text_primary));
        labelView.setTextSize(13f);
        addView(labelView);

        final int normalColor = getResources().getColor(R.color.text_primary);
        final int focusedColor = getResources().getColor(R.color.text_on_focus);
        setOnFocusChangeListener((v, hasFocus) -> {
            float scale = hasFocus ? 1.08f : 1f;
            animate()
                    .scaleX(scale)
                    .scaleY(scale)
                    .setDuration(120)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
            labelView.setTextColor(hasFocus ? focusedColor : normalColor);
            setElevation(hasFocus ? 8f : 0f);
        });
    }

    public void bind(AppInfo app) {
        Drawable icon = app.newIcon();
        if (icon == null) {
            icon = getResources().getDrawable(R.drawable.ic_app_placeholder, getContext().getTheme());
        }
        iconView.setImageDrawable(icon);
        labelView.setText(app.getLabel());
        setContentDescription(app.getLabel());
    }

    private static int dp(Context context, int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }
}
