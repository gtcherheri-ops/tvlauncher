package com.tvlauncher.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Beranda launcher: daftar aplikasi, favorit, pencarian, dan status jaringan. */
public class MainActivity extends Activity {
    private static final int CARD_SIZE_DP = 150;
    private static final long NETWORK_REFRESH_MS = 10_000L;

    private final List<AppInfo> allApps = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private FavoritesManager favoritesManager;
    private WallpaperController wallpaperController;
    private LinearLayout favoritesRow;
    private TextView favoritesEmpty;
    private GridLayout appsGrid;
    private EditText searchInput;
    private TextView networkStatus;
    private TextView noApps;

    private final Runnable networkUpdater = new Runnable() {
        @Override
        public void run() {
            updateNetworkStatus();
            handler.postDelayed(this, NETWORK_REFRESH_MS);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        favoritesManager = new FavoritesManager(this);
        wallpaperController = new WallpaperController(
                this,
                (ImageView) findViewById(R.id.wallpaper_image),
                (ImageView) findViewById(R.id.wallpaper_image_alt),
                findViewById(R.id.wallpaper_overlay));
        favoritesRow = findViewById(R.id.favorites_row);
        favoritesEmpty = findViewById(R.id.favorites_empty);
        appsGrid = findViewById(R.id.apps_grid);
        searchInput = findViewById(R.id.search_input);
        networkStatus = findViewById(R.id.network_status);
        noApps = findViewById(R.id.no_apps);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                refresh();
            }
        });

        findViewById(R.id.settings_button).setOnClickListener(
                v -> startActivity(new Intent(MainActivity.this, SettingsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInstalledApps();
        refresh();
        handler.removeCallbacks(networkUpdater);
        handler.post(networkUpdater);
        wallpaperController.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(networkUpdater);
        wallpaperController.stop();
    }

    @Override
    public void onBackPressed() {
        // Tombol back pada remote tidak boleh menutup launcher.
        if (!TextUtils.isEmpty(searchInput.getText())) {
            searchInput.setText("");
            searchInput.clearFocus();
        }
    }

    private void loadInstalledApps() {
        allApps.clear();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> installed = pm.getInstalledApplications(0);

        for (ApplicationInfo info : installed) {
            if (TextUtils.equals(info.packageName, getPackageName())) {
                continue;
            }
            Intent launchIntent = pm.getLaunchIntentForPackage(info.packageName);
            if (launchIntent == null) {
                continue;
            }
            String label = info.loadLabel(pm).toString().trim();
            if (label.isEmpty()) {
                label = info.packageName;
            }
            Drawable icon = info.loadIcon(pm);
            allApps.add(new AppInfo(label, info.packageName, launchIntent, icon));
        }

        Collections.sort(allApps, Comparator.comparing(AppInfo::getLabel, String.CASE_INSENSITIVE_ORDER));
    }

    private void refresh() {
        String query = searchInput.getText().toString().trim().toLowerCase(Locale.getDefault());
        List<AppInfo> favorites = filter(favoritesManager.getFavorites(allApps), query);
        List<AppInfo> apps = filter(allApps, query);

        favoritesRow.removeAllViews();
        appsGrid.removeAllViews();
        favoritesEmpty.setVisibility(favorites.isEmpty() ? View.VISIBLE : View.GONE);
        noApps.setVisibility(favorites.isEmpty() && apps.isEmpty() ? View.VISIBLE : View.GONE);

        int cardSize = dp(CARD_SIZE_DP);
        for (AppInfo app : favorites) {
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(cardSize, cardSize);
            params.setMargins(6, 6, 6, 6);
            favoritesRow.addView(createCard(app), params);
        }

        for (AppInfo app : apps) {
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = cardSize;
            params.height = cardSize;
            params.setMargins(6, 6, 6, 6);
            appsGrid.addView(createCard(app), params);
        }

        // Jangan pindahkan fokus dari kolom pencarian saat pengguna mengetik.
        if (searchInput.hasFocus() || (favorites.isEmpty() && apps.isEmpty())) {
            return;
        }
        View firstCard = favorites.isEmpty() ? appsGrid.getChildAt(0) : favoritesRow.getChildAt(0);
        if (firstCard != null) {
            firstCard.post(firstCard::requestFocus);
        }
    }

    private List<AppInfo> filter(List<AppInfo> source, String query) {
        if (query.isEmpty()) {
            return source;
        }
        List<AppInfo> result = new ArrayList<>();
        for (AppInfo app : source) {
            String label = app.getLabel().toLowerCase(Locale.getDefault());
            String packageName = app.getPackageName().toLowerCase(Locale.getDefault());
            if (label.contains(query) || packageName.contains(query)) {
                result.add(app);
            }
        }
        return result;
    }

    private AppCardView createCard(AppInfo app) {
        AppCardView card = new AppCardView(this);
        card.bind(app);
        card.setOnClickListener(v -> launchApp(app));
        card.setOnLongClickListener(v -> {
            showAppOptions(app);
            return true;
        });
        return card;
    }

    private void launchApp(AppInfo app) {
        try {
            startActivity(app.getLaunchIntent());
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.app_launched_error, Toast.LENGTH_SHORT).show();
        }
    }

    private void showAppOptions(AppInfo app) {
        boolean favorite = favoritesManager.isFavorite(app);
        String[] options = {
                getString(R.string.action_open),
                getString(favorite ? R.string.action_unfavorite : R.string.action_favorite),
                getString(R.string.action_app_info)
        };

        new AlertDialog.Builder(this)
                .setTitle(app.getLabel())
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        launchApp(app);
                    } else if (which == 1) {
                        favoritesManager.toggle(app);
                        refresh();
                        Toast.makeText(this,
                                getString(favorite ? R.string.action_unfavorite : R.string.action_favorite),
                                Toast.LENGTH_SHORT).show();
                    } else if (which == 2) {
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        intent.setData(Uri.parse("package:" + app.getPackageName()));
                        try {
                            startActivity(intent);
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(this, R.string.app_launched_error, Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private void updateNetworkStatus() {
        ConnectivityManager manager =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        int message = R.string.network_offline;

        if (manager != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network network = manager.getActiveNetwork();
                NetworkCapabilities capabilities = manager.getNetworkCapabilities(network);
                if (capabilities != null) {
                    if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        message = R.string.network_wifi;
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                        message = R.string.network_ethernet;
                    } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                        message = R.string.network_mobile;
                    }
                }
            } else {
                NetworkInfo info = manager.getActiveNetworkInfo();
                if (info != null && info.isConnected()) {
                    if (info.getType() == ConnectivityManager.TYPE_WIFI) {
                        message = R.string.network_wifi;
                    } else if (info.getType() == ConnectivityManager.TYPE_ETHERNET) {
                        message = R.string.network_ethernet;
                    } else if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
                        message = R.string.network_mobile;
                    }
                }
            }
        }
        networkStatus.setText(message);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
