package com.tvlauncher.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

/** Preferensi tambahan untuk wallpaper otomatis. */
public class LauncherPreferences {
    private static final String PREF_NAME = "tv_launcher_prefs";
    private static final String KEY_TREE_URI = "wallpaper_tree_uri";
    private static final String KEY_ENABLED = "wallpaper_enabled";
    private static final String KEY_INTERVAL = "wallpaper_interval_min";
    private static final String KEY_INDEX = "wallpaper_index";
    private static final String KEY_FORCE_NEXT = "wallpaper_force_next";
    private static final String KEY_FADE_MS = "wallpaper_fade_ms";

    public static final int DEFAULT_INTERVAL_MINUTES = 5;
    public static final int DEFAULT_FADE_MS = 800;
    public static final int[] INTERVAL_VALUES = {1, 5, 15, 30};
    public static final int[] FADE_VALUES = {0, 400, 800, 1200};

    private final SharedPreferences preferences;

    public LauncherPreferences(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public String getTreeUri() {
        return preferences.getString(KEY_TREE_URI, "");
    }

    public void setTreeUri(String uri) {
        preferences.edit()
                .putString(KEY_TREE_URI, uri == null ? "" : uri)
                .putInt(KEY_INDEX, 0)
                .apply();
    }

    public boolean isEnabled() {
        return preferences.getBoolean(KEY_ENABLED, true);
    }

    public void setEnabled(boolean enabled) {
        preferences.edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    public int getIntervalMinutes() {
        return preferences.getInt(KEY_INTERVAL, DEFAULT_INTERVAL_MINUTES);
    }

    public void setIntervalMinutes(int minutes) {
        preferences.edit().putInt(KEY_INTERVAL, minutes).apply();
    }

    public int getIndex() {
        return preferences.getInt(KEY_INDEX, 0);
    }

    public void setIndex(int index) {
        preferences.edit().putInt(KEY_INDEX, index).apply();
    }

    public boolean hasTree() {
        return !TextUtils.isEmpty(getTreeUri());
    }

    public void requestNext() {
        preferences.edit().putBoolean(KEY_FORCE_NEXT, true).apply();
    }

    public boolean consumeForceNext() {
        boolean requested = preferences.getBoolean(KEY_FORCE_NEXT, false);
        if (requested) {
            preferences.edit().putBoolean(KEY_FORCE_NEXT, false).apply();
        }
        return requested;
    }

    public int getFadeMs() {
        return preferences.getInt(KEY_FADE_MS, DEFAULT_FADE_MS);
    }

    public void setFadeMs(int fadeMs) {
        preferences.edit().putInt(KEY_FADE_MS, fadeMs).apply();
    }
}
