package com.tvlauncher.app;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.view.View;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Menampilkan dan mengganti gambar latar beranda secara berkala. */
public class WallpaperController {
    private static final String LOCAL_FOLDER = "wallpapers";
    private static final long MINUTE_MS = 60_000L;
    // Fade duration dibaca dari preferensi.

    private final Context context;
    private final ImageView primaryImage;
    private final ImageView secondaryImage;
    private final View overlayView;
    private final LauncherPreferences preferences;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Uri> images = new ArrayList<>();

    private final Runnable rotateRunnable = new Runnable() {
        @Override
        public void run() {
            showNext(true);
            schedule();
        }
    };

    private int index = 0;
    private String loadedKey = "";
    private Bitmap primaryBitmap;
    private Bitmap secondaryBitmap;
    private boolean primaryActive = true;
    private boolean hasShownImage = false;

    public WallpaperController(Context context, ImageView primaryImage, ImageView secondaryImage, View overlayView) {
        this.context = context;
        this.primaryImage = primaryImage;
        this.secondaryImage = secondaryImage;
        this.overlayView = overlayView;
        this.preferences = new LauncherPreferences(context);
    }

    public void start() {
        stop();
        if (!preferences.isEnabled()) {
            clear();
            return;
        }

        rebuildImages();
        if (images.isEmpty()) {
            clear();
            return;
        }

        index = Math.min(Math.max(preferences.getIndex(), 0), images.size() - 1);
        String key = imageKey();
        if (!key.equals(loadedKey)) {
            if (showAt(index, false)) {
                loadedKey = key;
            }
        } else if (!hasShownImage) {
            showAt(index, false);
        }

        if (preferences.consumeForceNext()) {
            showNext(true);
        }
        schedule();
    }

    public void stop() {
        handler.removeCallbacks(rotateRunnable);
    }

    private void schedule() {
        handler.removeCallbacks(rotateRunnable);
        if (images.isEmpty()) {
            return;
        }
        long interval = Math.max(1, preferences.getIntervalMinutes()) * MINUTE_MS;
        handler.postDelayed(rotateRunnable, interval);
    }

    private void showNext(boolean animate) {
        if (images.isEmpty()) {
            return;
        }
        index = (index + 1) % images.size();
        preferences.setIndex(index);
        showAt(index, animate);
    }

    private boolean showAt(int position, boolean animate) {
        Bitmap bitmap = decode(images.get(position));
        if (bitmap == null) {
            return false;
        }

        ImageView active = primaryActive ? primaryImage : secondaryImage;
        ImageView inactive = primaryActive ? secondaryImage : primaryImage;
        Bitmap outgoingBitmap = primaryActive ? secondaryBitmap : primaryBitmap;

        if (!hasShownImage || !animate) {
            active.animate().cancel();
            inactive.animate().cancel();
            active.setImageBitmap(bitmap);
            active.setAlpha(1f);
            active.setVisibility(View.VISIBLE);
            inactive.setImageBitmap(null);
            inactive.setAlpha(0f);
            inactive.setVisibility(View.GONE);
            overlayView.setVisibility(View.VISIBLE);
            recycleBitmap(outgoingBitmap);
            if (primaryActive) {
                primaryBitmap = bitmap;
                secondaryBitmap = null;
            } else {
                secondaryBitmap = bitmap;
                primaryBitmap = null;
            }
            hasShownImage = true;
            return true;
        }

        inactive.animate().cancel();
        active.animate().cancel();
        inactive.setImageBitmap(bitmap);
        inactive.setAlpha(0f);
        inactive.setVisibility(View.VISIBLE);
        overlayView.setVisibility(View.VISIBLE);

        long fadeDuration = Math.max(0, preferences.getFadeMs());
        inactive.animate().alpha(1f).setDuration(fadeDuration).start();
        active.animate().alpha(0f).setDuration(fadeDuration).withEndAction(() -> {
            active.setVisibility(View.GONE);
            active.setImageBitmap(null);
            recycleBitmap(outgoingBitmap);
        }).start();

        if (primaryActive) {
            secondaryBitmap = bitmap;
            primaryBitmap = outgoingBitmap; // cleaned in endAction
        } else {
            primaryBitmap = bitmap;
            secondaryBitmap = outgoingBitmap;
        }
        primaryActive = !primaryActive;
        hasShownImage = true;
        return true;
    }

    private void clear() {
        handler.removeCallbacks(rotateRunnable);
        primaryImage.animate().cancel();
        secondaryImage.animate().cancel();
        primaryImage.setImageBitmap(null);
        secondaryImage.setImageBitmap(null);
        primaryImage.setAlpha(1f);
        secondaryImage.setAlpha(0f);
        primaryImage.setVisibility(View.GONE);
        secondaryImage.setVisibility(View.GONE);
        overlayView.setVisibility(View.GONE);
        recycleBitmap(primaryBitmap);
        recycleBitmap(secondaryBitmap);
        primaryBitmap = null;
        secondaryBitmap = null;
        primaryActive = true;
        hasShownImage = false;
        loadedKey = "";
    }

    private void recycleBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            bitmap.recycle();
        }
    }

    private void rebuildImages() {
        images.clear();

        File externalDir = context.getExternalFilesDir(null);
        File[] files = externalDir == null
                ? null
                : new File(externalDir, LOCAL_FOLDER).listFiles((dir, name) -> {
                    String lower = name.toLowerCase();
                    return lower.endsWith(".jpg") || lower.endsWith(".jpeg")
                            || lower.endsWith(".png") || lower.endsWith(".webp");
                });
        if (files != null) {
            Arrays.sort(files, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
            for (File file : files) {
                images.add(Uri.fromFile(file));
            }
        }

        if (preferences.hasTree()) {
            try {
                Uri tree = Uri.parse(preferences.getTreeUri());
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(
                        tree, DocumentsContract.getTreeDocumentId(tree));
                Cursor cursor = context.getContentResolver().query(
                        children,
                        new String[]{
                                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                                DocumentsContract.Document.COLUMN_MIME_TYPE
                        },
                        null, null, null);
                if (cursor != null) {
                    try {
                        while (cursor.moveToNext()) {
                            String mime = cursor.getString(1);
                            if (mime == null || !mime.startsWith("image/")) {
                                continue;
                            }
                            String documentId = cursor.getString(0);
                            if (documentId != null) {
                                images.add(DocumentsContract.buildDocumentUriUsingTree(tree, documentId));
                            }
                        }
                    } finally {
                        cursor.close();
                    }
                }
            } catch (Exception ignored) {
            }
        }
    }

    private String imageKey() {
        StringBuilder builder = new StringBuilder();
        for (Uri uri : images) {
            builder.append(uri).append('|');
        }
        return builder.toString();
    }

    private Bitmap decode(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream stream = openImage(uri);
            if (stream == null) {
                return null;
            }
            try {
                BitmapFactory.decodeStream(stream, null, bounds);
            } finally {
                stream.close();
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                return null;
            }

            int maxWidth = Math.max(1, context.getResources().getDisplayMetrics().widthPixels);
            int maxHeight = Math.max(1, context.getResources().getDisplayMetrics().heightPixels);
            int sampleSize = 1;
            while (bounds.outWidth / sampleSize > maxWidth || bounds.outHeight / sampleSize > maxHeight) {
                sampleSize *= 2;
            }

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = sampleSize;
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            stream = openImage(uri);
            if (stream == null) {
                return null;
            }
            try {
                return BitmapFactory.decodeStream(stream, null, options);
            } finally {
                stream.close();
            }
        } catch (Exception e) {
            return null;
        }
    }

    private InputStream openImage(Uri uri) throws FileNotFoundException {
        if ("file".equals(uri.getScheme())) {
            return new FileInputStream(uri.getPath());
        }
        return context.getContentResolver().openInputStream(uri);
    }
}
