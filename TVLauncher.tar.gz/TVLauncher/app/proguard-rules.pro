# No custom ProGuard rules are required for this launcher.
