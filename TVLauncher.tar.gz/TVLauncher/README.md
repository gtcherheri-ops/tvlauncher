# TV Launcher

Launcher ringan untuk Android TV Box / Android TV. Ditulis dalam Java native (tanpa AndroidX), memakai
Gradle + Android Gradle Plugin. Proyek ini siap dibuka dan dibuild di Android Studio.

## Fitur

- Beranda sebagai launcher default (kategori `HOME` dan `LEANBACK_LAUNCHER`).
- Daftar semua aplikasi yang bisa diluncurkan, diurutkan berdasarkan nama.
- Baris **Favorit** — tahan tombol OK / long press pada aplikasi lalu pilih *Tambah ke Favorit*.
- Pencarian aplikasi berdasarkan nama atau package name.
- Navigasi D-pad remote: fokus kartu membesar + warna menyala, tombol OK untuk membuka.
- Tombol back tidak menutup launcher (hanya menghapus pencarian yang aktif).
- Jam, tanggal, dan status jaringan (WiFi / Ethernet / seluler / offline).
- Halaman Pengaturan: jadikan launcher utama, wallpaper sistem, kelola aplikasi, dan tentang.
- **Wallpaper otomatis**: gambar latar beranda berganti tiap 1/5/15/30 menit, dari folder pilihan
  atau dari folder khusus aplikasi (tanpa izin penyimpanan tambahan).
- Favorit dan preferensi wallpaper disimpan di `SharedPreferences`, tetap ada setelah reboot.

## Struktur singkat

```
TVLauncher/
├── app/src/main/java/com/tvlauncher/app/
│   ├── MainActivity.java        # beranda, daftar app, favorit, pencarian, jaringan
│   ├── SettingsActivity.java    # halaman pengaturan
│   ├── AppInfo.java             # model aplikasi
│   ├── AppCardView.java         # kartu aplikasi + animasi fokus
│   ├── FavoritesManager.java    # penyimpanan favorit
│   ├── LauncherPreferences.java # preferensi wallpaper otomatis
│   └── WallpaperController.java # rotasi gambar latar beranda
├── app/src/main/res/            # layout, drawable, warna, string
├── app/build.gradle
├── build.gradle
└── settings.gradle
```

## Build

Opsi A — Android Studio:

1. Buka Android Studio → **Open an Existing Project** → pilih folder `TVLauncher`.
2. Tunggu *Gradle Sync* selesai (Android Studio akan mengunduh Gradle 8.7 + AGP 8.5.2).
3. Hubungkan TV Box via USB debugging, lalu **Run** (`Shift+F10`).

Opsi B — command line (butuh JDK 17 dan `ANDROID_HOME` / `ANDROID_SDK_ROOT`):

```bash
cd TVLauncher
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Menjadikan launcher utama di TV Box

1. Tekan tombol **Home** di remote.
2. Saat muncul pilihan aplikasi, pilih **TV Launcher** → **Always**.
3. Atau buka menu launcher → **Pengaturan** → **Jadikan launcher utama**.

Jika tombol Home tidak menampilkan pilihan, buka *Settings → Apps → Default apps → Home app* lalu
pilih TV Launcher.

## Wallpaper otomatis

Buka **Pengaturan → Wallpaper otomatis (launcher)**:

1. **Pilih folder gambar** — pilih folder berisi file `.jpg`, `.jpeg`, `.png`, atau `.webp`
   melalui pemilih file sistem. Izin folder disimpan agar tetap berlaku setelah reboot.
2. **Interval** — pilih 1, 5, 15, atau 30 menit (default 5 menit).
3. **Ganti sekarang** — langsung menampilkan gambar berikutnya.
4. **Aktifkan / Nonaktifkan** — menyalakan atau mematikan rotasi.

Alternatif tanpa pemilih file: letakkan gambar di

```
/sdcard/Android/data/com.tvlauncher.app/files/wallpapers/
```

(bisa lewat `adb push`). Gambar dari kedua sumber digabungkan dan diurutkan berdasarkan nama.
Latar diberi overlay gelap agar teks tetap terbaca. Jika folder kosong, launcher memakai gradien bawaan.

## Catatan

- `minSdk 21` (Android 5.0), `targetSdk 35`, `compileSdk 35`.
- Izin `QUERY_ALL_PACKAGES` dipakai agar launcher bisa melihat semua aplikasi di Android 11+.
  Untuk distribusi Google Play, izin ini dibatasi kebijakan; untuk sideload / pemakaian pribadi
  di TV Box tidak masalah.
- Belum ada dependency AndroidX, jadi build lebih ringan dan konfigurasi lebih sederhana.

## Kustomisasi cepat

- Warna: `app/src/main/res/values/colors.xml`
- Teks: `app/src/main/res/values/strings.xml`
- Jumlah kolom grid: `android:columnCount` pada `res/layout/activity_main.xml`
- Ukuran kartu: `CARD_SIZE_DP` di `MainActivity.java` (sesuaikan juga ukuran di `AppCardView.java`)
